package com.example.transco

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
